package kr.ac.ssu.street4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Street4Application {

	public static void main(String[] args) {
		SpringApplication.run(Street4Application.class, args);
	}

}
