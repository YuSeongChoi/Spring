package kr.ac.ssu.eatgo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EatgoApplicationTests {

	@Test
	void contextLoads() {
	}

}
